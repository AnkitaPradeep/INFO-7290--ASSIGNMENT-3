use pubs;

go

/* Show the sql to find all the titles with more than one author */
SELECT A.title_id, a.title, COUNT(b.au_Id) FROM dbo.titles a
INNER JOIN dbo.titleauthor b on a.title_id = b.title_id
GROUP BY a.title_id,a.title
HAVING COUNT(b.au_id) > 1;

/*Show the sql to show all the authors with more than one book*/
SELECT a.au_fname, a.au_lname, COUNT(c.title_id)
FROM DBO.authors a
INNER JOIN dbo.titleauthor B  on a.au_id = b.au_id
INNER JOIN dbo.titles c on b.title_id = c.title_id
GROUP BY A.au_fname, A.au_lname
HAVING COUNT(c.title_id) > 1;


/*Show the sql to show the publishers with no titles*/
SELECT a.pub_id, a.pub_name
FROM dbo.publishers a
LEFT JOIN dbo.titles b ON A.pub_id = B.pub_id
WHERE b.title_id IS NULL; 